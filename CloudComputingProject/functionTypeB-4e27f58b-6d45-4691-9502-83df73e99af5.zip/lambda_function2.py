import json
import boto3

def reverse_words(content):
    reversed_content = ""
    lines = content.strip().split('\n')
    for line in lines:
        reversed_line = " ".join(word[::-1] for word in line.split())
        reversed_content += f"{reversed_line}\n"
    
    return reversed_content

def lambda_handler(event, context):
    s3_client = boto3.client('s3')
    input_bucket_name = event['bucket']
    output_bucket_name = 'group-f-output'
    file_key = event['key']
    print(file_key)

    # Read the content of the file from the input bucket
    file_content = s3_client.get_object(Bucket=input_bucket_name, Key=file_key)['Body'].read().decode('utf-8')
    print(file_content)

    # Reverse words in the file content
    reversed_content = reverse_words(file_content)
    print(reversed_content)

    # Upload the reversed content to the output bucket with the same key
    s3_client.put_object(
        Bucket=output_bucket_name,
        Key=file_key,
        Body=reversed_content.encode('utf-8')
    )
    return {
        'statusCode': 200,
        'body': json.dumps('All files processed successfully')
    }
