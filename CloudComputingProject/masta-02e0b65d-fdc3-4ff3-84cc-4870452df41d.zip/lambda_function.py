import json
import boto3

lambda_client = boto3.client('lambda')

def lambda_handler(event, context):
    record = event['Records'][0]
    bucket_name = record['s3']['bucket']['name']
    file_key = record['s3']['object']['key']
    if 'TypeA/' in file_key:#
        lambda_client.invoke(
        FunctionName='arn:aws:lambda:eu-north-1:199371276584:function:functionTypeA',
        InvocationType='Event',
        Payload=json.dumps({'key': file_key, 'bucket': bucket_name})
        )
    if 'TypeB/' in file_key:#
        lambda_client.invoke(
        FunctionName='arn:aws:lambda:eu-north-1:199371276584:function:functionTypeB',
        InvocationType='Event',
        Payload=json.dumps({'key': file_key, 'bucket': bucket_name})
        )
    if 'TypeC/' in file_key:#
        lambda_client.invoke(
        FunctionName='arn:aws:lambda:eu-north-1:199371276584:function:functionTypeC',
        InvocationType='Event',
        Payload=json.dumps({'key': file_key, 'bucket': bucket_name})
        )