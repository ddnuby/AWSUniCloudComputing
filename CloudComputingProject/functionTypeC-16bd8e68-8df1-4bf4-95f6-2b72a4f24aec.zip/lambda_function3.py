import json
import boto3

def binary_to_ascii(content):
    ascii_content = ""
    lines = content.strip().split('\n')
    for line in lines:
        binary_values = line.split()
        try:
            ascii_characters = ''.join([chr(int(b, 2)) for b in binary_values])
            ascii_content += f"{ascii_characters}\n"
        except ValueError:
            ascii_content += f"Invalid Binary Sequence\n"

    return ascii_content


def lambda_handler(event, context):
    s3_client = boto3.client('s3')
    input_bucket_name = event['bucket']
    output_bucket_name = 'group-f-output'
    file_key = event['key']

    # Read the content of the file from the input bucket
    file_content = s3_client.get_object(Bucket=input_bucket_name, Key=file_key)['Body'].read().decode('utf-8')

    # Convert binary numbers to ASCII in the file content
    ascii_content = binary_to_ascii(file_content)

    # Upload the ASCII content to the output bucket with the same key
    s3_client.put_object(
        Bucket=output_bucket_name,
        Key=file_key,
        Body=ascii_content.encode('utf-8')
    )

    return {
        'statusCode': 200,
        'body': json.dumps('Binary to ASCII conversion completed and saved to output bucket successfully.')
    }