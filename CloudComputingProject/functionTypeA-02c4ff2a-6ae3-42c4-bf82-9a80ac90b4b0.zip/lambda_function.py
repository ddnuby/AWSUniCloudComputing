import json
import boto3

def solve_equations(content):
    print("Content before solving equations:")
    print(content)
    
    solved_content = ""
    equations = content.strip().split('\n')
    for equation in equations:
        print("Equation before processing:")
        print(equation)
        
        # Split the equation by '=' sign to separate the equation from its result
        parts = equation.split('=')
        if len(parts) == 2:
            # Extract the equation and result
            equation_str, result_str = parts
            try:
                # Print the equation string before evaluation
                print("Equation string before evaluation:")
                print(equation_str.strip())
                
                # Evaluate the equation
                result = eval(equation_str.strip())
                # Append the equation and result to the solved content
                solved_content += f"{equation_str.strip()} = {result}\n"
            except Exception as e:
                # If evaluation fails, append the original equation to the solved content with an error message
                solved_content += f"{equation_str.strip()} = Evaluation Error: {str(e)}\n"
        else:
            # If the equation format is incorrect, append it to the solved content with an error message
            solved_content += f"{equation} = Invalid Equation Format\n"

    print("Content after solving equations:")
    print(solved_content)
    
    return solved_content


def lambda_handler(event, context):
    s3_client = boto3.client('s3')
    input_bucket_name = event['bucket']
    output_bucket_name = 'group-f-output'
    file_key = event['key']

    # Read the content of the file from the input bucket
    file_content = s3_client.get_object(Bucket=input_bucket_name, Key=file_key)['Body'].read().decode('utf-8')

    # Solve equations in the file content
    solved_content = solve_equations(file_content)

    # Upload the solved content to the output bucket with the same key
    s3_client.put_object(
        Bucket=output_bucket_name,
        Key=file_key,
        Body=solved_content.encode('utf-8')
    )

    return {
        'statusCode': 200,
        'body': json.dumps('Equations solved and saved to output bucket successfully.')
    }

