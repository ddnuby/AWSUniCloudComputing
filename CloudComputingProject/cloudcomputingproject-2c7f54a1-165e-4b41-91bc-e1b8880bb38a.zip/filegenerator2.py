import os
import boto3
import json
import random
import string
import random_words



output_directory = "/tmp/generated_files"  # Using /tmp directory for Lambda
os.makedirs(output_directory, exist_ok=True)

def generate_random_word(length):
    return ''.join(random.choice(string.ascii_lowercase) for _ in range(length))

def generate_files(event, context):
    for file_type in ['TypeA', 'TypeB', 'TypeC']:
        for i in range(1, 101):  # Generate 100 files of each type
            file_name = f"{file_type}_file_{i}.txt"
            file_path = os.path.join(output_directory, file_name)

            with open(file_path, 'w') as file:
                if file_type == 'TypeA':
                    for _ in range(4):  # Generate four lines of equations
                        a = random.randint(1, 100)
                        b = random.randint(1, 100)
                        operator = random.choice(['+', '-', '*', '/'])
                        if operator == '/':
                            a = b * random.randint(1, 10)  # Ensure division result is an integer
                        problem = f"{a} {operator} {b}"
                        file.write(f"{problem} =\n")

                elif file_type == 'TypeB':
                    for _ in range(4):  # Generate four lines of random words
                        word_length = random.randint(5, 10)
                        word = generate_random_word(word_length)
                        file.write(f"{word}\n")

                elif file_type == 'TypeC':
                    for _ in range(4):  # Generate four lines of binary numbers
                        binary_data = ''.join(random.choice(['0', '1']) for _ in range(10))
                        file.write(f"{binary_data}\n")

    upload_to_s3()
    
    return {
        'statusCode': 200,
        'body': json.dumps('Files generated and uploaded to S3 successfully.')
    }

def upload_to_s3():
    s3 = boto3.client('s3')
    bucket_name = 'group-f'

    for file_type in ['TypeA', 'TypeB', 'TypeC']:
        for i in range(1, 101):
            file_name = f"{file_type}_file_{i}.txt"
            file_path = os.path.join(output_directory, file_name)

            s3.upload_file(file_path, bucket_name, f"input/{file_type}/{file_name}")

    print("Files uploaded to S3 successfully.")

# For local testing
if __name__ == '__main__':
    generate_files(None, None)


